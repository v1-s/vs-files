import React, { useState } from 'react';
import Mbox from './Mbox'; 

export default function Popup() {
//   const [showAddProf, setShowAddProf] = useState(false);

  return (
    <div>
      {/* <button onClick={() => setShowAddProf(true)}>Add profile</button> */}
         <Mbox/>
    
    </div>
  );
}

chrome.webNavigation.onCompleted.addListener(function(details) {
    chrome.tabs.get(details.tabId, function(tab) {
      chrome.storage.sync.get(['blocklist'], function(result) {
        const blocklist = result.blocklist || [];
        const url = new URL(tab.url);
  
        if (blocklist.includes(url.hostname)) {
          chrome.tabs.update(details.tabId, { url: 'blocked.html' });
        }
      });
    });
  }, { url: [{ urlMatches: 'http://*/*' }, { urlMatches: 'https://*/*' }] });
  